# Chapter03-2
# 파이썬 문자형
# 문자형 중요

# 문자형 생성
str1 = "I am Python"
str2 = 'Python'
str3 = """How are you?"""
str4 = '''Thank you!'''

print(type(str1), type(str2), type(str3), type(str4))
print(len(str1), len(str2), len(str3), len(str4))

# 빈 문자열
str_t1 = ''
str_t2 = str()

print(type(str_t1), len(str_t1))
print(type(str_t2), len(str_t2))


# 이스케이프 문자 사용
# I'm boy
"""
참고 : Escape 코드

\n : 개행
\t : 탭
\\ : 문자
\' : 문자
\" : 문자
\000 : 널 문자
...
"""

print("I'm boy")
print('I\'m boy')
print('a \t b') # 탭
print('a \n b') # 줄바꿈
print('a \"\" b')

escape_str1 = "Do you have a \"retro games\"?"
print(escape_str1)
escape_str2 = 'What\'s on TV?'
print(escape_str2)

# 탭, 줄 바꿈
t_s1 = "Click \t Start!"
t_s2 = "New Line \nCheck!"

print(t_s1)
print(t_s2)
print()

# Raw String
raw_s = r'D:\pythonn\test' #소문자 r''
print(raw_s)